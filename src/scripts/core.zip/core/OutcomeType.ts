enum OutcomeType {
  SUCCESS = 'SUCCESS',
  NOT_ATTEMPTED = 'NOT_ATTEMPTED',
  FAILURE = 'FAILURE',
}

export { OutcomeType };
