export enum GameSystemType {
    DND5E = 'dnd5e'
}